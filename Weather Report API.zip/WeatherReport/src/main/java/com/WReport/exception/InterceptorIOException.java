package com.WReport.exception;

@SuppressWarnings("serial")
public class InterceptorIOException extends RuntimeException{
	public InterceptorIOException(String message) {
		super(message);
	}
}
